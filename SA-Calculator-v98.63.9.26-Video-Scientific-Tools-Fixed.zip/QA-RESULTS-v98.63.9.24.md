# QA results — v98.63.9.24 (Actions version-code hotfix)

- Release regression suite including Android native branding/version tests: **52/52 passed**.
- Android native branding isolated fixture: **5/5 passed**.
- Android web bundle preparation: **PASS**, 13 required assets verified.
- JavaScript syntax for native patch script: **PASS**.
- Workflow YAML parse: **PASS**.
- APK versionCode source-of-truth: package metadata `1098072`; native patcher and workflow final AAPT gate now consume the same selected-source value.
- Exact-version source archive ambiguity is rejected rather than resolved silently.

The GitHub Actions Android APK build was not rerun in this local environment; final native APK versionCode verification must be confirmed by rerunning the updated workflow. Physical-device install, rendering, touch latency and frame pacing are not certified.
