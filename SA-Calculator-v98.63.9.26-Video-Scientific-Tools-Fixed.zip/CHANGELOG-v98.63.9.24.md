# Changelog — v98.63.9.24

- Reworked the scientific drawer to match the supplied reference recording: flat pink panel, unboxed text-only scientific keys, no helper captions/display strip above or below the keys, and a separate dark circular More control.
- Removed card borders, key backgrounds, rounded key tiles, and per-key shadows from both the primary and expanded scientific function grids.
- Kept the 4×4 primary function matrix, INV state, More/expanded functions, existing data attributes, and JavaScript insertion/action handlers intact.
- Kept keyboard focus indication and minimum 48px touch targets.
- Preserved the main calculator keypad, calculation engine, scientific parser and tool destinations.

- Fixed GitHub Actions APK identity gate: `androidVersionCode: 1098072` is now explicit in `package.json`, consumed by the native Gradle patcher and exported by exact-source selection; final AAPT verification compares against that selected-source output instead of a mismatched hardcoded literal.
- Added exact-version archive ambiguity rejection so multiple matching ZIPs cannot be selected silently.
- Included Android native-branding/version metadata regression tests in the release test command.
